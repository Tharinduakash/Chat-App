// server.c

#include <stdio.h>
#include <winsock2.h>



#define MAX_CLIENTS 10

void handleClient(SOCKET clientSocket) {
    char buffer[1024];
    int bytesRead;

    while (1) {
        bytesRead = recv(clientSocket, buffer, sizeof(buffer), 0);
        if (bytesRead <= 0) {
            printf("Client disconnected.\n");
            break;
        }

        buffer[bytesRead] = '\0';
        printf("Client says: %s\n", buffer);

        printf("Enter your response: ");
        fgets(buffer, sizeof(buffer), stdin);
        send(clientSocket, buffer, strlen(buffer), 0);
    }

    closesocket(clientSocket);
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <IP address> <Port number>\n", argv[0]);
        return 1;
    }

    WSADATA wsaData;
    SOCKET serverSocket, clientSocket;
    struct sockaddr_in serverAddr, clientAddr;
    int clientAddrLen = sizeof(clientAddr);

    // Initialize Winsock
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        fprintf(stderr, "WSAStartup failed.\n");
        return 1;
    }

    // Create socket
    serverSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (serverSocket == INVALID_SOCKET) {
        fprintf(stderr, "Error creating socket.\n");
        WSACleanup();
        return 1;
    }

    // Set up server address structure
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = inet_addr(argv[1]); // IP address from command line
    serverAddr.sin_port = htons(atoi(argv[2]));     // Port number from command line

    // Bind the socket
    if (bind(serverSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR) {
        fprintf(stderr, "Bind failed.\n");
        closesocket(serverSocket);
        WSACleanup();
        return 1;
    }

    // Listen for incoming connections
    if (listen(serverSocket, MAX_CLIENTS) == SOCKET_ERROR) {
        fprintf(stderr, "Listen failed.\n");
        closesocket(serverSocket);
        WSACleanup();
        return 1;
    }

    printf("Server listening on %s:%s...\n", argv[1], argv[2]);

    while (1) {
        // Accept a client connection
        clientSocket = accept(serverSocket, (struct sockaddr*)&clientAddr, &clientAddrLen);
        if (clientSocket == INVALID_SOCKET) {
            fprintf(stderr, "Accept failed.\n");
            closesocket(serverSocket);
            WSACleanup();
            return 1;
        }

        printf("Client connected: %s\n", inet_ntoa(clientAddr.sin_addr));

        // Handle the client in a separate thread or process (for simplicity, we use a function here)
        handleClient(clientSocket);
    }

    // Clean up
    closesocket(serverSocket);
    WSACleanup();

    return 0;
}

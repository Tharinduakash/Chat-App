// client.c

#include <stdio.h>
#include <winsock2.h>
#include <string.h>

#define MAX_MESSAGE_LENGTH 1024

int main(int argc, char *argv[]) {
    WSADATA wsaData;
    SOCKET clientSocket;
    struct sockaddr_in serverAddr;
    char message[MAX_MESSAGE_LENGTH];

    // Check if the correct number of command-line arguments is provided
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <Server IP address> <Port>\n", argv[0]);
        return 1;
    }

    // Initialize Winsock
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        fprintf(stderr, "WSAStartup failed.\n");
        return 1;
    }

    // Create socket
    clientSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (clientSocket == INVALID_SOCKET) {
        fprintf(stderr, "Error creating socket.\n");
        WSACleanup();
        return 1;
    }

    // Set up server address structure
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = inet_addr(argv[1]); // Use the provided IP address from the command line
    serverAddr.sin_port = htons(atoi(argv[2]));     // Use the provided port from the command line

    // Connect to server
    if (connect(clientSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR) {
        fprintf(stderr, "Connection failed.\n");
        closesocket(clientSocket);
        WSACleanup();
        return 1;
    }

    printf("Connected to server at %s:%s\n", argv[1], argv[2]);

    while (1) {
        printf("Enter your message (type 'exit' to close): ");
        fgets(message, sizeof(message), stdin);

        // Send message to server
        send(clientSocket, message, strlen(message), 0);

        // Check if the user wants to exit
        if (strncmp(message, "exit", 4) == 0) {
            printf("Exiting client.\n");
            break;
        }

        // Receive response from server
        int bytesRead = recv(clientSocket, message, sizeof(message) - 1, 0);
        if (bytesRead <= 0) {
            printf("Server disconnected.\n");
            break;
        }

        // Null-terminate the received message
        message[bytesRead] = '\0';

        printf("Server says: %s\n", message);
    }

    // Clean up
    closesocket(clientSocket);
    WSACleanup();

    return 0;
}
